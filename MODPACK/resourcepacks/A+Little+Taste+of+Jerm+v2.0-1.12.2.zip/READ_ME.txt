A Little Taste of Jerm
==========================================================
Textures borrowed from other packs(with permission):
Bdoubleo's Resource Pack: Smooth Sandstone, Bricks, End Stone Bricks, and Iron Block.
Rukbukus's Resource Pack: Wheat and Flowers(Slightly Edited).
The Excalibur Resource Pack by Maffhew: Wheat textures/models https://www.planetminecraft.com/texture_pack/110-excalibur/
Rain sounds from the Conquest Resource Pack.

==========================================================
Changelog (V1.2)
New Nether Wart Item
New Minecart item and entity textures
New Ice & Packed Ice
New Log Tops & Stripped Log Tops
Slightly changed the fish buckets
Slightly changed Carrot on a Stick
Slightly changed Bookshelves
Slightly changed Phantom Membrane
Changed Stone Brick, Andesite Brick, Granite Brick, and Diorite Brick overlays
Changed End Stone, End Stone Bricks, End Portal Frame, Eye of Ender, and Ender Pearl
Changed Brown Mushroom item & block.
Changed Repeater and Comparator items
Changed Dried Kelp item
Changed Azure Bluet, Blue Orchid, and Allium
Changed Egg
Changed Trip Wire Hook
Changed Bowl, Mushroom Stew, and Rabbit Stew
Changed Oxeye Daisy
Changed Snow Block
Changed Netherrack & Nether Quartz Ore
Changed Water back to default for 1.13

Changelog (V1.1)
Added a bunch of the new default textures
Changed Path Block textures
Slight edit to Acacia Leaves
Slight edit to Dark Oak Leaves and Sapling
Fixed some issues with overlays and shaders
Fixed some issues with grass from Biomes O' Plenty
Fixed Cyan Carpet Model

Changelog 4/19/2018 (V1.0)
Completely changed Red Sand, and Sandstone to blend with the brick colors
Changed Sea Pickles that are not in water to look like Candles
Added the new vanilla Fern, Tall Fern, new Stone Brick types as variations
Changed the bookshelves to match a bit better
Changed Red Nether Brick
Changed Oak, Dark Oak, Spruce, and Birch Leaves
Changed the Spruce Sapling
Slightly changed the color of Diamond and Gold, and added in the new default armor textures
Changed the Fish item textures
Changed pork, golden apples, apple, cake, chicken, beef, potato, rabbit, and mutton textures
Desaturated all the stone, stone brick, and cobblestone blocks
Changed Blue Ice
Changed the Purple wool, dye, concrete, and bed
Changed Magenta Wool
Changed Sand Color, and Sandstone Textures
Changed Bucket Textures
Changed biome colors back to vanilla colors
Changed Terracotta and Stained Terracottas
Changed Double Tall Grass
Changed Oak, Spruce, Birch, and Dark Oak Saplings
Slightly Changed dirt, and other dirt related blocks
Added Dolphins
Added Turtles
Added Turle Eggs
Added Kelp
Added Seagrass
Added all Stripped Log variants
Added New Spruce Leaves Textures